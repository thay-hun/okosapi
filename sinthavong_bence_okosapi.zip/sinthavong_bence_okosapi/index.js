const express = require("express");
const app = express();
const port = 3000;

app.use(express.json());

const greetings = [
    "Remekül vagyok, köszi!",
    "Szuper napom van!",
    "Egy kicsit fáradtan, de jól!",
    "Köszönöm, jól érzem magam!",
    "Nagyon termékeny nap ez!",
    "Kávé után mindig jobban megy!",
    "Remekül, és te?",
    "Tele vagyok energiával!",
    "Egész jól, köszönöm!",
    "Ma Premo hangulatom van!"
];

let usedIndexes = new Set();

app.get('/api/time', (req, res) => {
    const now = new Date();
    const time = now.toTimeString().split(' ')[0];
    res.json({ time });
});

app.get('/api/date', (req, res) => {
    const today = new Date().toISOString().split('T')[0];
    res.json({ date: today });
});

app.get('/api/temp', async (req, res) => {
    try {
        const url = "https://api.open-meteo.com/v1/forecast?latitude=46.77&longitude=17.25&current_weather=true";
        const response = await fetch(url);
        const data = await response.json();

        if (!data.current_weather || typeof data.current_weather.temperature === 'undefined') {
            return res.status(500).json({ error: "Nem sikerült lekérni az időjárási adatokat!" });
        }

        res.json({ temperature: data.current_weather.temperature });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: "Hiba történt az API lekérés közben!" });
    }
});

app.get('/api/greetings', (req, res) => {
    if (usedIndexes.size === greetings.length) usedIndexes.clear();

    let index;
    do {
        index = Math.floor(Math.random() * greetings.length);
    } while (usedIndexes.has(index));

    usedIndexes.add(index);
    res.json({ greeting: greetings[index] });
});

app.listen(port, () => {
    console.log(`OkosAPI szerver fut: http://localhost:${port}`);
});
